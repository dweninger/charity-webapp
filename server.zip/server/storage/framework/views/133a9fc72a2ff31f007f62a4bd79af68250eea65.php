<?php $__env->startSection('content'); ?>

<h1>Make a Donation to <?php echo e($event->name); ?></h1>

<form method="POST" action="/events/<?php echo e($event->id); ?>/donate-confirm">
<?php echo e(method_field('PATCH')); ?>

<?php echo e(csrf_field()); ?>

  <div class="form-row">
    <div class="form-group col-md-4">
      <label for="inputAmount">Amount</label>
      <input type="number" step="0.01" class="form-control" id="inputAmount" name="donation_amount" placeholder="Amount" min="0.01" required>
    </div>
</div>
    <p name='event_id' hidden><?php echo e($event->id); ?></p>
    <p name='user_id' hidden><?php echo e(Auth::user()->id); ?></p>
  <button type="submit" class="btn btn-primary">Donate!</button>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/daniel/Documents/UWL.Fall.2021/Fall2021/cs741/project/server/resources/views/user/event-donate.blade.php ENDPATH**/ ?>