<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html>
    <head>
    <title></title>

    
    </head>
    <body>
        <h1>Deactivate User</h1>
        <table class="table table-striped">
            <tr>
                <th>ID</th>
                <th>First</th>
                <th>Last</th>
                <th>Email</th>
                <th>DOB</th>
                <th>Date Joined</th>
                <th>Type</th>
            </tr>
                <tr>
                    <td name='id'> <?php echo e($user->id); ?></td>
                    <td name='description'> <?php echo e($user->first); ?> </td>
                    <td name='last'> <?php echo e($user->last); ?> </td>
                    <td name='email'><?php echo e($user->email); ?></td>
                    <td name='dob'> <?php echo e($user->dob); ?> </td>
                    <td name='date_joined'> <?php echo e($user->date_joined); ?> </td>
                    <td name='type'> <?php echo e($user->type); ?> </td>
                </tr>
        </table>
        
        <form method="POST" action="/users/<?php echo e($user->id); ?>/deactivate-confirm">
            <?php echo e(method_field('PATCH')); ?>

            <?php echo e(csrf_field()); ?>

            <p name='user_id' hidden><?php echo e(Auth::user()->id); ?></p>
            <button type="submit" class="btn btn-danger">Confirm Deactivate</button>
        </form>
    </body>
</html>    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/daniel/Documents/UWL.Fall.2021/Fall2021/cs741/project/server/resources/views/admin/deactivate-user.blade.php ENDPATH**/ ?>