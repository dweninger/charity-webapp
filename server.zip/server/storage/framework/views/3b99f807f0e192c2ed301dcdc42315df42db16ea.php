<?php $__env->startSection('content'); ?>

<!DOCTYPE html>
<html>
    <head>
    <title></title>

    
    </head>
    <body>
    
        <h1>Users</h1>
        <table class="table table-striped">
            <tr>
                <th>ID</th>
                <th>First</th>
                <th>Last</th>
                <th>Email</th>
                <th>DOB</th>
                <th>Date Joined</th>
                <th>Type</th>
                <th>Active</th>
                <th></th>
                <th></th>
                <th></th>
            </tr>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td> <?php echo e($user->id); ?> </td>
                    <td> <?php echo e($user->first); ?> </td>
                    <td> <?php echo e($user->last); ?> </td>
                    <td> <?php echo e($user->email); ?> </td>
                    <td> <?php echo e($user->dob); ?> </td>
                    <td> <?php echo e($user->date_joined); ?> </td>
                    <td> <?php echo e($user->type); ?> </td>
                    <?php if($user->active == true): ?>
                    <td>Y</td>
                    <?php else: ?>
                    <td>N</td>
                    <?php endif; ?>
                    <td><a class="btn btn-primary" href="/users" role="button">Edit</a></td>
                    <td><a class="btn btn-info" href="/users" role="button">Stats</a></td>
                    <?php if($user->active == true): ?>
                    <td><a class="btn btn-danger" href="/users/<?php echo e($user->id); ?>/deactivate" role="button">Deactivate</a></td>
                    <?php else: ?>
                    <td><a class="btn btn-success" href="/users/<?php echo e($user->id); ?>/activate" role="button">Activate</a></td>
                    <?php endif; ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/daniel/Documents/UWL.Fall.2021/Fall2021/cs741/project/server/resources/views//admin/check-users.blade.php ENDPATH**/ ?>