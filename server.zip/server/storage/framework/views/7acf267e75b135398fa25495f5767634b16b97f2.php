<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html>
    <head>
    <title></title>

    
    </head>
    <body>
    
        <h1>My Donations</h1>
        <table class="table table-striped">
            <tr>
                <th>Amount</th>
                <th>Event</th>
                <th>Restricted</th>
                <th>Timestamp</th>
            </tr>
            <?php $__currentLoopData = $user_events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user_event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($user_event->donation_amount > 0): ?>
                <tr>
                    <td> $<?php echo e($user_event->donation_amount); ?></td>
                    <td> <?php echo e($user_event->name); ?> </td>
                    <td> Restricted </td>
                    <td><?php echo e($user_event->date); ?></td>
                </tr>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php $__currentLoopData = $u_donations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u_donation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>$<?php echo e($u_donation->donation_amount); ?></td>
                    <td>-</td>
                    <td>Unrestricted</td>
                    <td><?php echo e($u_donation->date); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/daniel/Documents/UWL.Fall.2021/Fall2021/cs741/project/server/resources/views/user/my-donations.blade.php ENDPATH**/ ?>