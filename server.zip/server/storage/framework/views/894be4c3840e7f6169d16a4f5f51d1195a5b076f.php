<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html>
    <head>
    <title></title>

    
    </head>
    <body>
        <h1>Cancel</h1>
        <table class="table table-striped">
            <tr>
                <th>Name</th>
                <th>Description</th>
                <th>Date</th>
                <th>Slots</th>
            </tr>
            <?php $__currentLoopData = $user_events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user_event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td name='name'> <?php echo e($user_event->name); ?></td>
                    <td name='description'> <?php echo e($user_event->description); ?> </td>
                    <td name='date'> <?php echo e($user_event->date_time); ?> </td>
                    <td name='volunteer_slots'> <?php echo e($user_event->volunteer_slots); ?> </td>
                </tr>
            
        </table>
        
        <form method="POST" action="/user-events/<?php echo e($user_event->id); ?>,<?php echo e($user_event->user_id); ?>,<?php echo e($user_event->event_id); ?>">
            <?php echo e(method_field('PATCH')); ?>

            <?php echo e(csrf_field()); ?>

            <p name='event_id' hidden><?php echo e($user_event->event_id); ?></p>
            <p name='user_id' hidden><?php echo e(Auth::user()->id); ?></p>
            <button type="submit" class="btn btn-primary">Confirm Cancelation</button>
        </form>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </body>
</html>    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/daniel/Documents/UWL.Fall.2021/Fall2021/cs741/project/server/resources/views/user/cancel_volunteer.blade.php ENDPATH**/ ?>