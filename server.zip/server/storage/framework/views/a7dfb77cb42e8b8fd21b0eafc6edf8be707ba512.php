<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html>
    <head>
    <title></title>

    
    </head>
    <body>
    
        <h1>My Volunteer Appointments</h1>
        <table class="table table-striped">
            <tr>
                <th>Name</th>
                <th>Description</th>
                <th>Date</th>
                <th>Hours</th>
                <th>Cancel</th>
            </tr>
            <?php $__currentLoopData = $user_events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user_event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($user_event->status =='signed_up'): ?>
                <tr>
                    <td> <?php echo e($user_event->name); ?></td>
                    <td> <?php echo e($user_event->description); ?> </td>
                    <td> <?php echo e($user_event->date_time); ?> </td>
                    <td> <?php echo e($user_event->hours); ?> </td>
                    <?php if($user_event->status == 'signed_up'): ?>
                    <td><a class="btn btn-primary" href="/user-events/<?php echo e($user_event->id); ?>,<?php echo e($user_event->user_id); ?>,<?php echo e($user_event->event_id); ?>/edit" role="button">Cancel</a></td>
                    <?php endif; ?>
                </tr>
                <?php endif; ?>
                <?php if($user_event->status == 'cancelled'): ?>
                <tr>
                    <td><del><?php echo e($user_event->name); ?></del></td>
                    <td><del><?php echo e($user_event->description); ?></del></td>
                    <td><del><?php echo e($user_event->date_time); ?></del></td>
                    <td><del><?php echo e($user_event->hours); ?></del></td>
                    <td class="text-danger font-weight-bold">Cancelled</td>
                </tr>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/daniel/Documents/UWL.Fall.2021/Fall2021/cs741/project/server/resources/views/user/my-events.blade.php ENDPATH**/ ?>