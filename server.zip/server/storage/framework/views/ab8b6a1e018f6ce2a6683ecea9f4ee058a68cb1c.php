<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html>
    <head>
    <title></title>

    
    </head>
    <body>
    
        <h1>Programs</h1>
        <table class="table table-striped">
            <tr>
                <th>Name</th>
                <th>Description</th>
            </tr>
            <?php $__currentLoopData = $programs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td> <?php echo e($program->name); ?></td>
                    <td> <?php echo e($program->description); ?> </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/daniel/Documents/UWL.Fall.2021/Fall2021/cs741/project/server/resources/views/programs.blade.php ENDPATH**/ ?>