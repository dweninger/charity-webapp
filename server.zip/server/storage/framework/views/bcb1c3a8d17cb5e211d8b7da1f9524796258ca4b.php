<?php $__env->startSection('content'); ?>

<!DOCTYPE html>
<html>
    <head>
    <title></title>
    
    </head>
    <body>
        <h1>Events</h1>

        <table class="table table-striped">
            <tr>
                <th>Name</th>
                <th>Description</th>
                <th>Date</th>
                <th>Hours</th>
                <th>Slots</th>
                <th>Donated</th>
                <th>Donation Goal</th>     
                <th></th>
                <?php if(auth()->guard()->check()): ?>
                <?php if(Auth::user()->type == "admin" || Auth::user()->type == "Donor"): ?>
                <th></th>
                <?php endif; ?>
                <?php if(Auth::user()->type == "admin"): ?>
                <th></th>
                <th></th>
                <?php endif; ?>
                <?php endif; ?>
            </tr>
            <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($event->active == true): ?>
                <tr>
                    <td> <?php echo e($event->name); ?> </td>
                    <td> <?php echo e($event->description); ?> </td>
                    <td> <?php echo e($event->date_time); ?> </td>
                    <td> <?php echo e($event->hours); ?> </td>
                    <td> <?php echo e($event->volunteer_slots); ?> </td>
                    <td> $<?php echo e($event->donated_amount); ?> </td>
                    <td> $<?php echo e($event->donation_goal); ?> </td>
                    <?php if(auth()->guard()->check()): ?>
                    
                    <?php
                        $volunteer_conflict = false;
                        foreach($user_events as $user_event){
                            if($user_event->events_id == $event->id) {
                                if($user_event->status == 'signed_up'){
                                    $volunteer_conflict = true;
                                } 
                            }

                            $event_time = $event->date_time;
                            $event_time_array = explode(" ", $event_time);
                            $event_time_time_array = explode(":", $event_time_array[1]);
                            $event_end_time_hours = intval($event_time_time_array[0]) + $event->hours;

                            $user_event_time = $user_event->date_time;
                            $user_event_time_array = explode(" ", $user_event_time);
                            $user_event_time_time_array = explode(":", $user_event_time_array[1]);
                            
                            if($event_time_array[0] == $user_event_time_array[0]){
                                if(intval($event_time_time_array[0]) <= intval($user_event_time_time_array[0])){
                                    if($event_end_time_hours > intval($user_event_time_time_array[0])){
                                        if($user_event->status == 'signed_up'){
                                            $volunteer_conflict = true;
                                        } 
                                    }
                                }
                            }
                        }

                        $date_facturation = \Carbon\Carbon::parse($event->date_time)
                    ?>
                    

                    <!-- Volunteer Button -->
                    <?php if($event->volunteer_slots > 0): ?>
                        <?php if($date_facturation->isPast()): ?>
                            <td class="text-danger font-weight-bold">Past Event</td>
                        <?php else: ?>
                            <?php if($volunteer_conflict != true): ?>
                                <td><a class="btn btn-primary" href="/events/<?php echo e($event->id); ?>/volunteer" role="button">Volunteer</a></td>
                            <?php else: ?>
                                <td class="text-danger font-weight-bold">Time Conflict</td>
                            <?php endif; ?>
                        <?php endif; ?>
                    <?php else: ?>
                        <td class="text-danger font-weight-bold">Full</td>
                    <?php endif; ?>
                    <?php endif; ?>
                    <?php if(Auth::guest()): ?>
                    <td></td>
                    <?php endif; ?>
                    
                    <!-- Donate Button -->
                    <?php if(auth()->guard()->check()): ?>
                    <?php if(Auth::user()->type == "admin" || Auth::user()->type == "Donor"): ?>
                        <?php if($date_facturation->isPast()): ?>
                            <td></td>
                        <?php else: ?>
                            <td><a class="btn btn-success" href="/events/<?php echo e($event->id); ?>/donate" role="button">Donate</a></td>
                        <?php endif; ?>
                    <?php endif; ?>

                    <!-- Admin Buttons -->
                    <?php if(Auth::user()->type == "admin"): ?>
                        <td><a class="btn btn-info" href="/events/<?php echo e($event->id); ?>" role="button">Info</a></td>
                        <?php if($date_facturation->isPast()): ?>
                            <td></td>
                        <?php else: ?>
                            <td><a class="btn btn-danger" href="/events/<?php echo e($event->id); ?>/cancel" role="button">Cancel</a></td>
                        <?php endif; ?>
                    <?php endif; ?>
                    <?php endif; ?>
                </tr>
                <?php else: ?>
                <tr>
                    <td><del> <?php echo e($event->name); ?> </del></td>
                    <td><del> <?php echo e($event->description); ?> </del></td>
                    <td><del> <?php echo e($event->date_time); ?> </del></td>
                    <td><del> <?php echo e($event->hours); ?> </del></td>
                    <td><del> <?php echo e($event->volunteer_slots); ?> </del></td>
                    <td><del> $<?php echo e($event->donated_amount); ?> </del></td>
                    <td><del> $<?php echo e($event->donation_goal); ?> </del></td>
                    <td class="text-danger font-weight-bold">Canceled Event</td>
                    <?php if(auth()->guard()->check()): ?>
                    <?php if(Auth::user()->type == "admin" || Auth::user()->type == "Donor"): ?>
                    <td></td>
                    <?php endif; ?>
                    <?php if(Auth::user()->type == "admin"): ?>
                    <td></td>
                    <td></td>
                    <?php endif; ?>
                    <?php endif; ?>
                </tr>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        <?php if(auth()->guard()->check()): ?>
            <?php if(Auth::user()->type == "admin"): ?>
                <div><a class="btn btn-primary float-right" href="/events/create" role="button">Create Event</a></div>
            <?php endif; ?>
        <?php endif; ?>
    </body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/daniel/Documents/UWL.Fall.2021/Fall2021/cs741/project/server/resources/views/events.blade.php ENDPATH**/ ?>