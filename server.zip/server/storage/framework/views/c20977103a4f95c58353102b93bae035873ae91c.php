<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html>
    <head>
    <title></title>

    
    </head>
    <body>
        <h1>Cancel Event</h1>
        <table class="table table-striped">
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Description</th>
                <th>Date/Time</th>
                <th>Hours</th>
                <th>Slots</th>
                <th>Donated</th>
                <th>Donation Goal</th>
            </tr>
                <tr>
                    <td name='id'> <?php echo e($event->id); ?></td>
                    <td name='description'> <?php echo e($event->name); ?> </td>
                    <td name='last'> <?php echo e($event->description); ?> </td>
                    <td name='email'><?php echo e($event->date_time); ?></td>
                    <td name='dob'> <?php echo e($event->hours); ?> </td>
                    <td name='date_joined'> <?php echo e($event->volunteer_slots); ?> </td>
                    <td name='type'> $<?php echo e($event->donated_amount); ?> </td>
                    <td name='type'> $<?php echo e($event->donation_goal); ?> </td>
                </tr>
        </table>
        
        <form method="POST" action="/events/<?php echo e($event->id); ?>/cancel-confirm">
            <?php echo e(method_field('PATCH')); ?>

            <?php echo e(csrf_field()); ?>

            <p name='user_id' hidden><?php echo e(Auth::user()->id); ?></p>
            <button type="submit" class="btn btn-danger">Confirm Cancel</button>
        </form>
    </body>
</html>    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/daniel/Documents/UWL.Fall.2021/Fall2021/cs741/project/server/resources/views/admin/cancel-event.blade.php ENDPATH**/ ?>