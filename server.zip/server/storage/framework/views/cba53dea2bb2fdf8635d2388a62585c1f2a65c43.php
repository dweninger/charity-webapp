<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html>
    <head>
    <title></title>

    
    </head>
    <body>
    
        <h1><?php echo e($user->first); ?> <?php echo e($user->last); ?></h1>

        <table class="table table-striped">
            <tr>
                <th>ID</th>
                <th>First</th>
                <th>Last</th>
                <th>Email</th>
                <th>DOB</th>
                <th>Date Joined</th>
                <th>Type</th>
                <th>Active</th>
                <th>Volunteer Hours</th>
                <?php if(Auth::user()->type  == "donor" || Auth::user()->type == "admin"): ?>
                <th>Total Donated</th>
                <?php endif; ?>
            </tr>
            <tr>
                <td><?php echo e($user->id); ?></td>
                <td><?php echo e($user->first); ?></td>
                <td><?php echo e($user->last); ?></td>
                <td><?php echo e($user->email); ?></td>
                <td><?php echo e($user->dob); ?></td>
                <td><?php echo e($user->date_joined); ?></td>
                <td><?php echo e($user->type); ?></td>
                <?php if($user->active == true): ?>
                <td>Y</td>
                <?php else: ?>
                <td>N</td>
                <?php endif; ?>

                <?php
                    $total_hours = 0;
                    $total_donation = 0;

                    foreach($user_events as $user_event){
                        if($user_event->status != 'cancelled'){
                            $total_hours += $user_event->hours;
                        }
                        $total_donation += $user_event->donation_amount;
                    }

                    foreach($u_donations as $u_donation){
                        $total_donation += $u_donation->donation_amount;
                    }
                ?>

                <td><?php echo e($total_hours); ?></td>
                <?php if(Auth::user()->type  == "donor" || Auth::user()->type == "admin"): ?>
                <td>$<?php echo e($total_donation); ?></td>
                <?php endif; ?>
            </tr>
        </table>
        <h3>Volunteering Stats</h3>
        <table class="table table-striped">
            <tr>
                <th>Event ID</th>
                <th>Event</th>
                <th>Description</th>
                <th>Date</th>
                <th>Hours</th>
                <th>Slots</th>
                <th></th>
            </tr>
            <?php $__currentLoopData = $user_events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($event->status != 'cancelled'): ?>
            <tr>
                <td><?php echo e($event->event_id); ?></td>
                <td><?php echo e($event->name); ?></td>
                <td><?php echo e($event->description); ?></td>
                <td><?php echo e($event->date_time); ?></td>
                <td><?php echo e($event->hours); ?></td>
                <td><?php echo e($event->volunteer_slots); ?></td>
                <td></td>
            </tr>
            <?php else: ?>
            <tr>
                <td><del><?php echo e($event->event_id); ?></del></td>
                <td><del><?php echo e($event->name); ?></del></td>
                <td><del><?php echo e($event->description); ?></del></td>
                <td><del><?php echo e($event->date_time); ?></del></td>
                <td><del><?php echo e($event->hours); ?></del></td>
                <td><del><?php echo e($event->volunteer_slots); ?></del></td>
                <td class="text-danger font-weight-bold">Cancelled Event</td>
            </tr>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>

        <?php if(auth()->guard()->check()): ?>
        <?php if(Auth::user()->type  == "donor" || Auth::user()->type == "admin"): ?>
        <h3>Unrestricted Donation Stats</h3>
        <table class="table table-striped">
            <tr>
                <th>Amount</th>
                <th>Date</th>
            </tr>
            <?php $__currentLoopData = $u_donations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u_donation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>$<?php echo e($u_donation->donation_amount); ?></td>
                <td><?php echo e($u_donation->date); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        <h3>Restricted Donation Stats</h3>
        <table class="table table-striped">
            <tr>
                <th>Amount</th>
                <th>Event</th>
                <th>Date</th>
            </tr>
            <?php $__currentLoopData = $user_events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($event->donation_amount > 0): ?>
            <tr>
                <td>$<?php echo e($event->donation_amount); ?></td>
                <td><?php echo e($event->name); ?></td>
                <td><?php echo e($event->date); ?></td>
            </tr>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        <?php endif; ?>
        <?php endif; ?>
    </body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/daniel/Documents/UWL.Fall.2021/Fall2021/cs741/project/server/resources/views/admin/user-info.blade.php ENDPATH**/ ?>