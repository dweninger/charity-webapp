<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html>
    <head>
    <title></title>

    
    </head>
    <body>
        <h1>Events</h1>
        <table class="table table-striped">
            <tr>
                <th>Name</th>
                <th>Description</th>
                <th>Date</th>
                <th>Hours</th>
                <th>Slots</th>
            </tr>
                <tr>
                    <td name='name'> <?php echo e($event->name); ?></td>
                    <td name='description'> <?php echo e($event->description); ?> </td>
                    <td name='date'> <?php echo e($event->date_time); ?> </td>
                    <td name='hours'><?php echo e($event->hours); ?></td>
                    <td name='volunteer_slots'> <?php echo e($event->volunteer_slots); ?> </td>
                </tr>
        </table>
        
        <form method="POST" action="/events/<?php echo e($event->id); ?>/volunteer-confirm">
            <?php echo e(method_field('PATCH')); ?>

            <?php echo e(csrf_field()); ?>

            <p name='event_id' hidden><?php echo e($event->id); ?></p>
            <p name='user_id' hidden><?php echo e(Auth::user()->id); ?></p>
            <p name='volunteer_hours' hidden><?php echo e($event->hours); ?></p>
            <button type="submit" class="btn btn-primary">Confirm Volunteer</button>
        </form>
    </body>
</html>    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/daniel/Documents/UWL.Fall.2021/Fall2021/cs741/project/server/resources/views/user/volunteer.blade.php ENDPATH**/ ?>